import pandas as pd
import numpy as np
import os
import tensorflow as tf

# =====================
# CONFIG
# =====================
DISEASES = [
    "Cardiomegaly",
    "Edema",
    "Effusion",
    "Pneumonia",
    "Atelectasis",
    "Consolidation",
    "No Finding"
]

# =====================
# LABEL ENCODER
# =====================
def encode_labels(label_string):
    labels = label_string.split("|")
    return np.array([1 if d in labels else 0 for d in DISEASES], dtype=np.float32)

# =====================
# DATASET LOADER
# =====================
def load_dataset(
    csv_path,
    image_dir,
    img_size=(224, 224),
    batch_size=16,
    split="train"
):
    df = pd.read_csv(csv_path)

    # shuffle rows
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)

    total = len(df)
    train_end = int(0.8 * total)
    val_end = int(0.9 * total)

    if split == "train":
        df = df[:train_end]
    elif split == "val":
        df = df[train_end:val_end]
    else:
        df = df[val_end:]

    image_paths = []
    labels = []

    for _, row in df.iterrows():
        img_path = os.path.join(image_dir, row["Image Index"])
        if os.path.exists(img_path):
            image_paths.append(img_path)
            labels.append(encode_labels(row["Finding Labels"]))

    image_paths = np.array(image_paths)
    labels = np.array(labels)

    def parse_image(path, label):
        img = tf.io.read_file(path)
        img = tf.image.decode_jpeg(img, channels=3)
        img = tf.image.resize(img, img_size)
        img = img / 255.0
        return img, label

    dataset = tf.data.Dataset.from_tensor_slices((image_paths, labels))
    dataset = dataset.map(parse_image, num_parallel_calls=tf.data.AUTOTUNE)

    if split == "train":
        dataset = dataset.shuffle(5000)

    dataset = dataset.batch(batch_size)
    dataset = dataset.prefetch(tf.data.AUTOTUNE)

    return dataset